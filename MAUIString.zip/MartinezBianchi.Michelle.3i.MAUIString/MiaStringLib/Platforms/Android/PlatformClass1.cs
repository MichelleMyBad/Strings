﻿namespace MiaStringLib
{
    // All the code in this file is only included on Android.
    public class PlatformClass1
    {
    }
}